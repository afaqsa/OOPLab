
package assignment01;

public class Main {

    
    public static void main(String[] args) {
        System.out.println("\t\t\t---------------------------");
        System.out.println("\t\t\t    DHA SUFFA UNIVERSITY");
        System.out.println("\t\t\t---------------------------");
        System.out.println("\t\t\t  Transcript");
        
        System.out.println("---------------------------------------------------------------");
        System.out.print("Name = Asma Qaiser \t\t");
        System.out.println("\t\tRoll no.= 201000");
        System.out.println("---------------------------------------------------------------");
        
        System.out.print("  Subject \t\t");
        System.out.println("\t\t\t\t Marks");
        System.out.println("---------------------------------------------------------------");
        
        System.out.print("Programming Fundamentals \t\t");
        System.out.println("\t\t 98");
        System.out.print("Programming Fundamentals Lab \t\t");
        System.out.println("\t\t 93");
        System.out.print("Applied Physics \t\t");
        System.out.println("\t\t\t 84");
        System.out.print("English \t\t\t");
        System.out.println("\t\t\t 93");
        System.out.print("Calculus \t\t\t ");
        System.out.println("\t\t\t 87");
        System.out.println("---------------------------------------------------------------");
      
        System.out.print("Prescentage \t\t\t ");
        System.out.println("\t\t\t 90.0%");
        System.out.print("Division \t\t\t ");
        System.out.println("\t\t\t First");
        System.out.println("---------------------------------------------------------------");
    }   
}
